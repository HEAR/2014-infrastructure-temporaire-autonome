_kiwi.view.Applet = _kiwi.view.Panel.extend({
    className: 'panel applet',
    initialize: function (options) {
        this.initializePanel(options);
    }
});